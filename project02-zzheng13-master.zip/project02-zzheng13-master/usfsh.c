#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <stdarg.h> 
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "list.h"

#define MAX_STR_LEN 128
#define MAX_ARGS 128
#define READ  0
#define WRITE 1
#define MAX_BUF_LEN 128
 
static int run(char* cmd, int input, int first, int last);
static char line[1024];
static int n = 0,count =0; /* number of calls to 'command' */
static char* args[512];

pid_t pid;
int command_pipe[2];

struct server_node
{
    struct list_elem elem;
    int countcam;
    char name[MAX_STR_LEN];
};

struct list server_list;

void print_server_list(struct list *l)
{
    struct list_elem *e;
    for(e = list_begin(l); e != list_end(l); e = list_next(e))
    {
        struct server_node *s = list_entry(e, struct server_node, elem);
        printf("%d : %s\n", s->countcam, s->name);
    }
    printf("\n");
}

struct server_node *find_server(struct list *l, char *name)
{
    struct list_elem *e;
    struct server_node *rv = NULL;
    for(e = list_begin(l); e != list_end(l); e = list_next(e)) 
    {
        struct server_node *s = list_entry(e, struct server_node, elem);
    	if(strstr(s->name,name)!=NULL)
    	{
      	    rv = s;
      	    break;
    	}
    }
    return rv;
}

struct server_node *find_num(struct list *l, char* counter)
{
    struct list_elem *e;
    struct server_node *rv = NULL;
    char str[5];
    for(e = list_begin(l); e != list_end(l); e = list_next(e)) 
    {
        struct server_node *s = list_entry(e, struct server_node, elem);
    	sprintf(str,"%d",s->countcam);
    	if (strcmp(str, counter) == 0) 
    	{
      	    rv = s;
      	    break;
    	}
    }
    return rv;
}

void debug_panic(const char *file, int line, const char *function,const char *message, ...)
{
    va_list args;
    printf ("Kernel PANIC at %s:%d in %s(): ", file, line, function);
    va_start (args, message);
    vprintf (message, args);
    printf ("\n");
    va_end (args);
    exit(-1);
}

static int command(int input, int first, int last, char * cmand)
{
    int pipettes[2];
    /* Invoke pipe */
    pipe( pipettes );	
    pid = fork();
    if(pid == 0) 
    {
        if(first == 1 && last == 0 && input == 0) 
        {
            // First command
            dup2( pipettes[WRITE], STDOUT_FILENO );
     	}else if(first == 0 && last == 0 && input != 0){
            // Middle command
	    dup2(input, STDIN_FILENO);
	    dup2(pipettes[WRITE], STDOUT_FILENO);
    	}else{			
            // Last command
            dup2( input, STDIN_FILENO );
    	}
        
        if(execvp( args[0], args) == -1)
     	{
            printf("%s: command not found\n", cmand); 
            // If child fails
            _exit(EXIT_FAILURE); 
        }
    }
    if(input != 0) 
        close(input);
    // Nothing more needs to be written
    close(pipettes[WRITE]);
    // If it's the last command, nothing more needs to be read
    if(last == 1)
        close(pipettes[READ]);
    return pipettes[READ];
}
 
/* Final cleanup, 'wait' for processes to terminate.
 *  n : Number of times 'command' was invoked.
 */
static void cleanup(int n)
{
    int i;
    for(i = 0; i < n; ++i) 
	wait(NULL); 
}
  
static char* skipwhite(char* s)
{
    while(isspace(*s)) ++s;
    return s;
}
 
static void split(char* cmd)
{
    cmd = skipwhite(cmd);
    char* next = strchr(cmd, ' ');
    int i = 0;
    while(next != NULL) 
    {
        next[0] = '\0';
     	args[i] = cmd;
    	++i;
        cmd = skipwhite(next + 1);
        next = strchr(cmd, ' ');
    }
    if(cmd[0] != '\0') 
    {
        args[i] = cmd;
        next = strchr(cmd, '\n');
        next[0] = '\0';
        ++i; 
    }
    args[i] = NULL;
}

 
static int run(char* cmd, int input, int first, int last)
{
    split(cmd);
    int fd ;
    int wri = 0;
    int rv =0;
    if(args[0] != NULL)
    {
        if(strcmp(args[0],"echo")==0)
        {
            int con = 0;
            while(args[con]!= NULL)
            {
                if(strcmp(args[con],">") == 0)
                {
                    fd = open(args[con+1],O_CREAT | O_TRUNC |O_WRONLY, 0644);
                    if(fd != -1)
                    {
                        wri = 1;
                    }
                    break;
                }
                con++;
            }
            if(wri == 1)
            {     
                int cou = 2;
                char* dest = malloc(sizeof(char)*(strlen(args[1])+1));
                strcpy(dest, args[1]);
                size_t length = 0;
                length = strlen(args[1]);
                while(cou < con)
                {
                    char* src = malloc(sizeof(char)*(strlen(args[cou])+1));
                    length = length + strlen(args[cou]);
                    strcpy(src,args[cou]);
                    length = length +1;
                    strcat(dest," ");
                    strcat(dest,src);
                    cou++;
                }
                strcat(dest,"\n");
                write(fd,dest, length+1);
                close(fd);
           }	  
       }
    }
    if(args[0] == NULL)
    {
        return 1;
    }
    struct server_node *s3;
    const char s[2] = "!";
    char *token;
    token = strtok(args[0],s);
    if(strcmp(token, args[0])!=0)
    {
        char *sss = (char*)malloc(sizeof(args[0]));
        strcpy(sss,args[0]);
        sss++;
        if((s3=find_num(&server_list,sss)) != NULL)
        {
            int input = 0;
            int first = 1;
            char* cmd = s3->name;
            /* Find first '|' */
            char* next = strchr(cmd, '|');
            while (next != NULL)
            {
                /* 'next' points to '|' */
                *next = '\0';
                input = run(cmd, input, first, 0);
                cmd = next + 1;
                /* Find next '|' */
                next = strchr(cmd, '|');
                first = 0;
            }
            input = run(cmd, input, first, 1);
            cleanup(n);
            n = 0;    
        }else if((s3= find_server(&server_list,sss)) != NULL){
            int input = 0;
            int first = 1;
            char* cmd = s3->name;
            /* Find first '|' */
            char* next = strchr(cmd, '|');
            while (next != NULL)
            {
                /* 'next' points to '|' */
                *next = '\0';
                input = run(cmd, input, first, 0);
                cmd = next + 1;
                /* Find next '|' */
                next = strchr(cmd, '|');
                first = 0;
            }
            input = run(cmd, input, first, 1);
            cleanup(n);
            n = 0;   
        }else{
            printf("Nothing match!\n");
        }
        return 1; 
    }  
    if(strcmp(args[0], "exit") == 0)
    { 
        exit(0);
    }
    if(strcmp(args[0],"history")==0)
    {
        print_server_list(&server_list);
        return 1;
    }
    if(strcmp(args[0],"cd")==0)
    {
        char * direc = "/home";
        if(args[1]==NULL) 
        {
            chdir(direc);   
        }else{
            if(chdir(args[1]))
            {
                printf("myselous:cd:%s:no such directory\n",args[1]);
            }  
        }
        return 1;
    }
    if(strcmp(args[0],"pwd")==0)
    {
        char buf[MAX_ARGS];
        printf("%s\n",getcwd(buf,sizeof(buf)));
        return 1;
    }
    if(args[0]==NULL)
    {
        return 0;
    }
    n += 1;
    return command(input, first, last,cmd);
}

static void writebuf(int countnum){
    int rv = 0;
    char str[8],bu[512];
    strcpy(line,"");
    char *buf1 = "[";
    char *buf2 = "]$";
    sprintf(str,"%s %d %s",buf1,countnum,buf2);
    rv = write(1,str,7);
    if(rv < 0)
    {
        printf("write() failed.\n");
        exit(-1);
    }
}

static void readtonode(struct server_node *snode, int countnum)
{
    int num;
    num = read(0,line,(MAX_BUF_LEN-1));
    if(num < 0)
    {
        printf("read() failed.\n");
        exit(-1);
    }
    line[num] = '\0';
    if(strcmp(line,"\n\0")!= 0)
    {
        struct server_node s1;
        snode = &s1;
        snode = malloc(sizeof(struct server_node));
        strncpy(snode->name, line, MAX_STR_LEN);
        snode->countcam = countnum;
        list_push_back(&server_list, &snode->elem);
        count++;
        if(count > 10)
        {
            list_pop_front(&server_list);
        }
    }
    
}

int main()
{ 
    struct server_node *s;     
    list_init(&server_list);
    while(1)
    {
        writebuf(count);
        fflush(NULL); 
        /* Read a command line */
        readtonode(s,count);
      	int input = 0;
    	int first = 1;
    	char* cmd = line;
    	/* Find first '|' */
    	char* next = strchr(cmd, '|'); 
    	while (next != NULL) 
    	{
            /* 'next' points to '|' */
            *next = '\0';
            input = run(cmd, input, first, 0);
            cmd = next + 1;
            /* Find next '|' */
            next = strchr(cmd, '|'); 
            first = 0;
    	}
        input = run(cmd, input, first, 1);
        cleanup(n);
        n = 0;
    }
    return 0;
}

#include "types.h" 
#include "stat.h" 
#include "user.h" 

int main(int argc, char **argv) 
{ 
  //int id;
  int count1;
  int count2;
  int fildes1[2];
  int fildes2[2];
  int fildes3[2];
  pipe(fildes1);
  pipe(fildes2);
  char fulltest[600] = {'0'};
  //char buf[100];

  //Test empty


printf(1,"empty pipe\n");
  count1 = pipe_count(fildes1[0]);
    count2 = pipe_count(fildes1[1]);
    printf(1,"This is count1: ");
    printf(1,"%d\n",count1);
    printf(1,"This is count2: ");
    printf(1,"%d\n",count2);


  //Test pipe full
    close(fildes2[0]);
    if (write(fildes2[1], fulltest, 600) < 0) {
            write(2, "Cannot write to pipe\n", 21);
        }

        printf(1,"full pipe\n");
  count1 = pipe_count(fildes2[0]);
    count2 = pipe_count(fildes2[1]);
    printf(1,"This is count1: ");
    printf(1,"%d\n",count1);
    printf(1,"This is count2: ");
    printf(1,"%d\n",count2);

  //Test pipe full-empty

    close(fildes1[0]);
    if (write(fildes1[1], "Hello child!", 13) < 0) {
            write(2, "Cannot write to pipe\n", 21);
        }

        printf(1,"full-empty pipe\n");
  count1 = pipe_count(fildes1[0]);
    count2 = pipe_count(fildes1[1]);
    printf(1,"This is count1: ");
    printf(1,"%d\n",count1);
    printf(1,"This is count2: ");
    printf(1,"%d\n",count2);

  //Test not valid pipe

close(fildes3[0]);
    if (write(fildes3[1], "Hello child!", 13) < 0) {
            write(2, "Cannot write to pipe\n", 21);
        }

        printf(1,"This is not a valid pipe\n");
  count1 = pipe_count(fildes3[0]);
    count2 = pipe_count(fildes3[1]);
    printf(1,"This is count1: ");
    printf(1,"%d\n",count1);
    printf(1,"This is count2: ");
    printf(1,"%d\n",count2);
  
  exit(); 
}
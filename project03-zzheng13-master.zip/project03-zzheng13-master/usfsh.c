#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include "list.h"
#include "stdlib.h"

#define MAX_STR_LEN 128
#define MAX_ARGS 128
#define READ  0
#define WRITE 1
#define MAX_BUF_LEN 128
 
static int run(char* cmd, int input, int first, int last);
static char line[1024];
static int n = 0,count =0; 
static char* args[512];

int pid;
int command_pipe[2];

static int command(int input, int first, int last, char* cmand)
{
    int pipettes[2];
    pipe(pipettes);   
    pid = fork();
    if(pid == 0) 
    {
        if(first == 1 && last == 0 && input == 0) 
        {
            close(1);
            dup(pipettes[WRITE]);
            close(pipettes[WRITE]);
        }else if(first == 0 && last == 0 && input != 0){
            close(0);
            dup(pipettes[READ]);
            close(pipettes[WRITE]);
            close(pipettes[READ]);
        }else{          
            close(0);
            dup( input);
            close(pipettes[WRITE]);
            close(pipettes[READ]);
        }
        if(exec(args[0], args) == -1)
        {
            printf(1,"%s: command not found\n", cmand);  
            exit(); 
        }
    }
    if(input != 0) 
        close(input);
    close(pipettes[WRITE]);
    if(last == 1)
        close(pipettes[READ]);
    return pipettes[READ];
}
 
static void cleanup(int n)
{
    int i;
    for(i = 0; i < n; ++i) 
    wait(); 
}
  
static char* skipwhite(char* s)
{
    while(isspace(*s)) ++s;
    return s;
}

struct linked_node
{
    struct list_elem elem;
    int countcam;
    char name[MAX_STR_LEN];
};

struct list linked_list;

void print_linked_list(struct list *l)
{
    struct list_elem *e;
    for(e = list_begin(l); e != list_end(l); e = list_next(e))
    {
        struct linked_node *s = list_entry(e, struct linked_node, elem);
        printf(1,"%d : %s\n", s->countcam, s->name);
    }
    printf(1,"\n");
}

struct linked_node *find_prefix(struct list *l, char *name)
{
    struct list_elem *e;
    struct linked_node *rv = NULL;
    for(e = list_begin(l); e != list_end(l); e = list_next(e)) 
    {
        struct linked_node *s = list_entry(e, struct linked_node, elem);
        if(strstr(s->name,name)!=NULL)
        {
            rv = s;
            break;
        }
    }
    return rv;
}

struct linked_node *find_num(struct list *l, char* counter)
{
    struct list_elem *e;
    struct linked_node *rv = NULL;
    char str[5];
    for(e = list_begin(l); e != list_end(l); e = list_next(e)) 
    {
        struct linked_node *s = list_entry(e, struct linked_node, elem);
        itoa(s->countcam,str);
        if (strcmp(str, counter) == 0) 
        {
            rv = s;
            break;
        }
    }
    return rv;
}

static void split(char* cmd)
{
    cmd = skipwhite(cmd);
    char* next = strchr(cmd, ' ');
    int i = 0;
    while(next != NULL) 
    {
        next[0] = '\0';
        args[i] = cmd;
        ++i;
        cmd = skipwhite(next + 1);
        next = strchr(cmd, ' ');
    }
    if(cmd[0] != '\0') 
    {
        args[i] = cmd;
        next = strchr(cmd, '\n');
        next[0] = '\0';
        ++i; 
    }
    args[i] = NULL;
}

static int run(char* cmd, int input, int first, int last)
{
    split(cmd);
    int fd ;
    int wri = 0;
    if(args[0] != NULL)
    {
        if(strcmp(args[0],"echo")==0)
        {
            int con = 0;
            while(args[con]!= NULL)
            {
                if(strcmp(args[con],">") == 0)
                {
                    fd = open(args[con+1],O_CREATE | O_RDWR);
                    if(fd != -1)
                    {
                        wri = 1;
                    }
                    break;
                }
                con++;
            }
            if(wri == 1)
            {     
                int cou = 2;
                char* dest = malloc(sizeof(char)*(strlen(args[1])+1));
                strcpy(dest, args[1]);
                size_t length = 0;
                length = strlen(args[1]);
                while(cou < con)
                {
                    char* src = malloc(sizeof(char)*(strlen(args[cou])+1));
                    length = length + strlen(args[cou]);
                    strcpy(src,args[cou]);
                    length = length +1;
                    strcat(dest," ");
                    strcat(dest,src);
                    cou++;
                }
                strcat(dest,"\n");
                write(fd,dest, length+1);
                close(fd);
            }      
        }
    }
    if(args[0] == NULL)
    {
        return 1;
    }
    struct linked_node *s3;
    const char s[2] = "!";
    char *token;
    token = strtok(args[0],s);
    if(strcmp(token, args[0])!=0)
    {
        if((s3=find_num(&linked_list,token)) != NULL)
        {
            int input = 0;
            int first = 1;
            char* cmd = s3->name;
            char* next = strchr(cmd, '|');
            while (next != NULL)
            {
                *next = '\0';
                input = run(cmd, input, first, 0);
                cmd = next + 1;
                next = strchr(cmd, '|');
                first = 0;
            }
            input = run(cmd, input, first, 1);
            cleanup(n);
            n = 0;    
        }else if((s3= find_prefix(&linked_list,token)) != NULL){
            int input = 0;
            int first = 1;
            char* cmd = s3->name;
            char* next = strchr(cmd, '|');
            while (next != NULL)
            {
                *next = '\0';
                input = run(cmd, input, first, 0);
                cmd = next + 1;
                next = strchr(cmd, '|');
                first = 0;
            }
            input = run(cmd, input, first, 1);
            cleanup(n);
            n = 0;   
        }else{
            printf(1,"Nothing match!\n");
        }
        return 1; 
    }  
    if(strcmp(args[0], "exit") == 0)
    { 
        exit();
    }
    if(strcmp(args[0],"history")==0)
    {
        print_linked_list(&linked_list);
        return 1;
    }
    if(strcmp(args[0],"cd")==0)
    {
        char * direc = "/home";
        if(args[1]==NULL) 
        {
            chdir(direc);   
        }else{
            if(chdir(args[1]))
            {
                printf(1,"myselous:cd:%s:no such directory\n",args[1]);
            }  
        }
        return 1;
    }
    if(args[0]==NULL)
    {
        return 0;
    }
    n += 1;
    return command(input, first, last,cmd);
}

static void writebuf(int countnum)
{
    int rv = 0;
    char str[8];
    char strs[8];
    strcpy(line,"");
    char *buf1 = "[";
    char *buf2 = "]$";
    strcpy(str, buf1);
    itoa(countnum,strs);
    strcat(str,strs);
    strcat(str,buf2);
    rv = write(1,str,7);
    if(rv < 0)
    {
        printf(1,"write() failed.\n");
        exit();
    }
}

static void readtonode(struct linked_node *snode, int countnum)
{
    int num;
    num = read(0,line,(MAX_BUF_LEN-1));
    if(num < 0)
    {
        printf(1,"read() failed.\n");
        exit();
    }
    line[num] = '\0';
    if(strcmp(line,"\n\0")!= 0)
    {
        struct linked_node s1;
        snode = &s1;
        snode = malloc(sizeof(struct linked_node));
        strncpy(snode->name, line, MAX_STR_LEN);
        snode->countcam = countnum;
        list_push_back(&linked_list, &snode->elem);
        count++;
        if(count > 10)
        {
            list_pop_front(&linked_list);
        }
    } 
}

int main()
{ 
    struct linked_node *s = malloc(sizeof(struct linked_node));     
    list_init(&linked_list);
    while(1)
    {
        writebuf(count);
        readtonode(s,count);
        int input = 0;
        int first = 1;
        char* cmd = line;
        char* next = strchr(cmd, '|'); 
        while (next != NULL) 
        {
            *next = '\0';
            input = run(cmd, input, first, 0);
            cmd = next + 1;
            next = strchr(cmd, '|'); 
            first = 0;
        }
        input = run(cmd, input, first, 1);
        cleanup(n);
        n = 0;
    }
    exit();
    return 0;
}

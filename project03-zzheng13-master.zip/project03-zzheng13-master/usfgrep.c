#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#define MAX_PATTERN_LEN 64
#define NULL (void *) 0
#define true 1

/* A struct used to package to return values */
struct grep_info{  
    char pattern[MAX_PATTERN_LEN];   
    char **files;
};

/* A struct used to store the content, length, line number of each line */
struct line_results{   
    int len;    
    int numline;   
    char buffer[512];
}; 

void print_usage(void){
    printf(1,"Usage: usfgrep <pattern> <file1> [<file2> ...]\n"); 
    return;
}

void parse_args(int argc, char **argv, struct grep_info *gi){ 
    if (argc < 3){    
        printf(1,"Insufficient arguments.\n");   
        print_usage();   
        exit();
    }
    if (strlen(argv[1]) > MAX_PATTERN_LEN){   
        printf(1,"The pattern you are looking for exceeds the length of 64 chars.");   
        exit();
    }    
    strcpy(gi->pattern, argv[1]);
    gi->files = argv + 2;  
    return;
}

/* Open a file, check for errors, return a valid fd */
int open_file(char *filename){ 
    int fd;
    fd = open(filename, O_RDONLY);
    if (fd < 0){
        printf(1,"Cannot open %s, exiting.\n", filename);
        exit();
    } 
    return fd;
}

struct line_results get_line(int fd){ 
    char buf[512];
    int rv;
    int count =0;
    struct line_results l;
    l.len = 0;
    l.numline = 0;
    static int counter = 1;
    strcpy(l.buffer, "");
    while ((rv = read(fd, buf, 1)) > 0){
        /* Check to make sure each line in the file is less than 512 bytes. */
        count++;
        if(count == 512){ 
            printf(1,"The line can't contain more than 511 bytes!\n");
            exit();
        }
        if (buf[0] == '\n'){   
            counter++;
            count = 0;
            break;
        }
        strcat(l.buffer, buf);
        l.len = l.len + 1;
        l.numline = counter;
    } 
    /* Check if we are at the end of the file. */ 
    if ((rv == 0) && (l.len == 0)){ 
        l.len = -1;
        counter = 1;
    }
    return l;
}

struct line_results grep_line(int argc,int fd, struct grep_info *gi,int i){
    char gline[511];
    char *ret;
    struct line_results l;   
    l = get_line(fd);
    strcpy(gline, l.buffer);    
    if(strlen(gline)>strlen(gi->pattern)){        
        ret = strstr(gline, gi->pattern);        
        if(ret != NULL){            
            if(argc == 3){                
                printf(1,"%d:%s\n", l.numline, gline);           
            }else{
                printf(1,"%s:%d:%s\n",gi->files[i],l.numline, gline);
            }
        }
    } 
    return l;
}

void grep_file(int argc,int i, struct grep_info *gi){
    struct line_results l;
    int fd;
    fd = open_file(gi->files[i]);
    int len = 0;
    /* Read the first line. */
    l = grep_line(argc,fd,gi,i);
    while (true){        
        l = grep_line(argc,fd,gi,i);        
        len = l.len;        
        if (len < 0){            
            break;
        }       
    }
    close(fd);
}   

void grep_files(int argc, struct grep_info *gi){    
    int i = 0;   
    /* If there is only one file. */
    if(argc == 3){      
        grep_file(argc,i, gi);    
    /* If there are multiple files. */
    }else{
        while (true){           
            if(gi->files[i] == NULL){                
                break;
            }
            grep_file(argc,i,gi);        
            i = i + 1;
        }
    }
}
    
int main(int argc, char **argv){     
    struct grep_info gi;    
    parse_args(argc, argv, &gi);
    grep_files(argc, &gi);
    exit();
    return 0;
}

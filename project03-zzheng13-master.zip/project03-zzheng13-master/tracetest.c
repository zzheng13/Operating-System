#include "types.h" 
#include "stat.h" 
#include "user.h" 
#include "fcntl.h"
#include "list.h"
#include "stdlib.h"

int main(int argc, char **argv) 
{ 
	int fd;
	fd = open("out.txt",O_CREATE | O_RDWR);
	trace_start();
	int pid;
	char *arr1[1] = { "a" };
	char *arr2[1] = { "b" };
	pid = fork();
	if(pid == 0){
		exec("a", arr1);
		exit();
	}
	pid = fork();
	if(pid == 0)
	{
		exec("b",arr2);
		exit();
	}
	wait();
	wait();
	trace_end(fd);
	exit();
}

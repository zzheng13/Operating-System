#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"
#include "assert.h"
#include "x86.h"
#include "stdlib.h"
#include "stddef.h"

char*
strcpy(char *s, char *t)
{
    char *os;
    os = s;
    while((*s++ = *t++) != 0)
        ;
    return os;
}

int
strcmp(const char *p, const char *q)
{
    while(*p && *p == *q)
        p++, q++;
    return (uchar)*p - (uchar)*q;
}

uint
strlen(char *s)
{
    int n;
    for(n = 0; s[n]; n++)
        ;
    return n;
}

void*
memset(void *dst, int c, uint n)
{
    stosb(dst, c, n);
    return dst;
}

char*
strchr(const char *s, char c)
{
    for(; *s; s++)
        if(*s == c)
            return (char*)s;
    return 0;
}

char*
gets(char *buf, int max)
{
    int i, cc;
    char c;
    for(i=0; i+1 < max; ){
        cc = read(0, &c, 1);
        if(cc < 1)
            break;
        buf[i++] = c;
        if(c == '\n' || c == '\r')
            break;
    }
    buf[i] = '\0';
    return buf;
}

int
stat(char *n, struct stat *st)
{
    int fd;
    int r;
    fd = open(n, O_RDONLY);
    if(fd < 0)
        return -1;
    r = fstat(fd, st);
    close(fd);
    return r;
}

int
atoi(const char *s)
{
    int n;
    n = 0;
    while('0' <= *s && *s <= '9')
        n = n*10 + *s++ - '0';
    return n;
}

void*
memmove(void *vdst, void *vsrc, int n)
{
    char *dst, *src;
    dst = vdst;
    src = vsrc;
    while(n-- > 0)
        *dst++ = *src++;
    return vdst;
}

char* 
strcat(char* s1, const char* s2)
{
    char* b = s1;
    while (*s1) ++s1;
    while (*s2) *s1++ = *s2++;
    *s1 = 0;
    return b;
}

char* 
strstr(const char* s1, const char* s2)
{
    const char* b2 = s2;
    if (!*s2)
        return (char*)s1;
    for (; *s1 && *s2; ++s1)
    {
        if (*s1==*s2)
            ++s2;
        else
            s2 = b2;
    }
    return *s2 ? NULL : (char*)(s1-(s2-b2));
}

char* 
strncpy(char* s1, const char* s2, uint n)
{
  uint i = 0;
  for (; i<n && s2[i]!=0; ++i)
      s1[i] = s2[i];
  for (; i < n; i++)
      s1[i] = 0;
  return s1;
}

void 
reverse(char* s)
 {
     int i, j;
     char c;
     for (i = 0, j = strlen(s)-1; i<j; i++, j--) 
     {
          c = s[i];
          s[i] = s[j];
          s[j] = c;
     }  
 }

 void 
 itoa(int n, char* s)
 {
      int i, sign;
      if ((sign = n) < 0)  /* record sign */
          n = -n;          /* make n positive */
      i = 0;
      do {       /* generate digits in reverse order */
          s[i++] = n % 10 + '0';   /* get next digit */
      } while ((n /= 10) > 0);     /* delete it */
      if (sign < 0)
          s[i++] = '-';
      s[i] = '\0';
      reverse(s);
 }

int 
isspace(int c)
{
    return c==' ' || c=='\f' || c=='\n' || c=='\r' || c=='\t' || c=='\v';
}

char*
strtok(char *str, const char* delim) 
{
    static char* buffer;
    if (str != NULL) {
        buffer = str;
    }
    if (buffer[0]=='\0') {
        return NULL;
    }
    char *ret = buffer, *b;
    const char *d;
    for (b = buffer; *b !='\0'; b++) {
        for (d = delim; *d != '\0'; d++) {
            if (*b == *d) {
                *b = '\0';
                buffer = b+1;
                if (b == ret) {
                    ret++;
                    continue;
                }
                return ret;
            }
        }
    }
    return ret;
}

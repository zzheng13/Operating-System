#ifndef _UCC_STDLIB_H
#define _UCC_STDLIB_H
#endif
#include "stddef.h"
#include "types.h"
#define RAND_MAX 2147483647

void abort(void);
int abs(int);
long strtol(const char *, char **, int);
int rand(void);
void srand(unsigned);
void *malloc(uint);
void *realloc(void *, uint);
void *calloc(uint, uint);
void free(void *);
//void exit(int);
int atoi(const char*);

#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int i, end;

  if(argc != 2){
    printf(1, "usage: seq <end>");
    exit();
  }

  end = atoi(argv[1]);
  
  for (i = 1; i <= end; i++) {
    printf(1, "%d\n", i);
  }

  exit();
}